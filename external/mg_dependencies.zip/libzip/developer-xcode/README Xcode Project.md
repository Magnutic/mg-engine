This Xcode project is for development only, it is not meant to compile production builds.

It is used internally to develop libzip and to run Xcode's diagnostic tools on the source.
