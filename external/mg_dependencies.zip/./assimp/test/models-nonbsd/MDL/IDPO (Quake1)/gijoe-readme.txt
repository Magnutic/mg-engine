Title    : G.I.Joe Skins
Filename : joemodel.zip
Version  : 1
Date     : 11/05/97
Author   : Kenneth Whelan
Email    : JWHELAN@pop.prodigy.net
Credits  : id software, Larry Hama, Steven Polge, and Rene Post for making Quake ME 
					
	

Build time: ??? Time???

Type of Mod
-----------
Quake C  : no
Sound    : no
MDL      : Yes  


Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no
context diff  : no
.qc files     : no
progs.dat     : no


Description of the Modification
-------------------------------

This is a new player.mdl for quake. It's main use is for bots. The Skins are Snake Eyes v4, Duke v3, Low-Light,
Storm Shadow v2, Shockwave, Repeater, Gung-Ho, Shipwreck, Dusty v3, and 
Tunnel Rat v2. 



Known bugs
None that I know of.

How to Install the Modification
-------------------------------

First back up the current player.mdl(copy player.mdl player.bak). Just put 
it in the progs dir in the hack your using, if any.

Technical Details
-----------------

can't think of any


Author Information
------------------

This is my first publicly distributed quake graphic change.
I did it to get away from the stress of school.


Copyright and Distribution Permissions
--------------------------------------

You may distribute this Quake modification in any electronic format as long as
 all the files in this archive remain intact and unmodified and are distributed
 together.


Availability
------------

This modification is available from the following places:

	http://www.yojoe.com/

