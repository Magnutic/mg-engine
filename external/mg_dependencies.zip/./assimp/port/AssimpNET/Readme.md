Please check the following git-repo for the source: https://github.com/kebby/assimp-net
